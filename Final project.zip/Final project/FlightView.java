package progproject;

import java.util.Map;

/**
 *
 * @author Uzair Lakhani, Muhammad Val
 */
public class FlightView {
    public static void printFlightDetails(Map map) {
        System.out.println(map);
    }
}
